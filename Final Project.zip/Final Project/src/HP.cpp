#include "HP.hpp"


HP::HP()
{

}

void HP::createHP(float HealthX, float HealthY, float Hwidth, float Hheight, float BordX, float BordY, float BordHeight, float BordWidth, float Ticks)
{
    HBorder.x = BordX;
    HBorder.y = BordY;
    HBorder.width = BordWidth;
    HBorder.height = BordHeight;
    Hticks = Ticks;

    for (int i = 0;i < Hticks;i++)
    {
        HealthBar[i].x = HealthX+i;
        HealthBar[i].y = HealthY;
        HealthBar[i].width = Hwidth;
        HealthBar[i].height = Hheight;
    }
}

void HP::draw(int Hred, int Hgreen, int Hblue, int Bred, int Bblue, int Bgreen)
{
    ofSetColor(Hred, Hgreen, Hblue);
    ofFill();
    for (int i = 0;i < Hticks;i++)
    {
        ofDrawRectangle(HealthBar[i]);
    }
   
    ofNoFill();
    ofSetColor(Bred, Bblue, Bgreen);
    ofDrawRectangle(HBorder);
}
