#include "ofMain.h"
#include <iostream>
#include <fstream>
#include <string>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define N_MAX 50000

using namespace std;

class EnemBullets
{

public:

    string phases;
  

    float x[N_MAX];
    float y[N_MAX];
    float width;
    float height;
    float r;
    int bulletNum1;
    

    //Phase 2 Sampling:additional variables-------------------------------
    int n;
    int numBullets;
    int bulletNum2;
    float x0;
    float y0;
    float step;
    float min;
    float max;
    
    float Input[N_MAX];
    float R[N_MAX];



    //-----------------------------------------------------------

    EnemBullets();
    EnemBullets(float x0_in, float y0_in, float min_in, float max_in, float step_in, float r_in, float width_in, float height_in);

    void print(string label);
    void setup(string label,ofPoint p);
    void update();
    void draw();

    int getUniformSamples(float samp[], float min, float max, float step);
    void createCircles(int n, int numBullets, float x[], float y[], float R, float theta[], float x0, float y0);

   

    

};
