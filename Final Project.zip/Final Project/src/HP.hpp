#include "ofMain.h"
#include <iostream>
#include <fstream>
#include <string>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


using namespace std;

#define N_MAX 50000
class HP
{
public:

    ofRectangle HealthBar[N_MAX];
    ofRectangle HBorder;

    ofColor Hcolor;
    ofColor Bcolor;

    float Hticks;

    HP();

    void createHP(float HealthX, float HealthY, float Hwidth, float Hheight, float BordX, float BordY, float BordHeight, float BordWidth,float Ticks);
    void draw(int Hred, int Hgreen, int Hblue, int Bred, int Bblue, int Bgreen);

};
