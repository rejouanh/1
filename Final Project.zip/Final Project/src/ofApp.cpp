#include "ofApp.h"

//=================================================================================
bool ofApp::Collision(float x1, float y1, float x2, float y2, float r1, float r2)
{
    float dist, sum, r;

    r = r1 + r2;

    sum = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);

    dist = sqrt(sum);

    if (dist > r) return(false);
    else if (dist <= r) return(true);
}

void ofApp::deleteIndex(int n, float x[], float y[], int index)
{
    for (int i = index;i < n-1;i++)
    {
        x[i] = x[i +1];
        y[i] = y[i + 1];
    }
}
//================================================================================
void ofApp::setup() {

    ofSetFrameRate(60);
    ofBackground(135, 200, 255);

    game_state = "game";
    phase_state ="phase1";
    score = 0;
    
    if (game_state == "game")
    {
        myPlayer.setup();
        lv.setup(ofGetElapsedTimef());
        HP_player.createHP(0, 0, 1, 15, 0, 0, 15, 250, 250);
        HP_enemy.createHP(300, 738, 0.5, 30, 300, 738, 30, 400, 400);
    }
      
    gameEnd1.load("gameEnd.png");
    gameEnd2.load("win.png");
}

//==============================================================================
void ofApp::update() {
    if (game_state == "game")
    {
        ebull.update();
    }
}

//==============================================================================
void ofApp::draw() {
    
    if (game_state == "game")
    {
        lv.interval_time = ofRandom(1, 10);
        myPlayer.draw();
        Enemy.setup(phase_state);
        Enemy.draw();
        bull.draw(0, 0, 255);
        HP_player.draw(0, 255, 0, 0, 0, 0);
        HP_enemy.draw(255, 0, 0, 0, 0, 0);

        if (HP_enemy.Hticks <= 300)
        {
           phase_state = "phase2";
        }
        if (HP_enemy.Hticks <= 150)
        {
            phase_state = "phase3";
        }
    //-----------------------------------------------------

        //Phase1:------------------------------------
        if (phase_state == "phase1")
        {
            ebull.draw();
            //Player bullet to enemy Collision
            for (int i = 0;i < bull.bulletNum;i++)
            {
                bull_to_enemy[i] = Collision(bull.x[i], bull.y[i], Enemy.pos2.x, Enemy.pos2.y, Enemy.r, bull.r);

                if (bull_to_enemy[i] == true)
                {
                    bull.bulletNum--;

                    HP_enemy.Hticks -= 2;;
                }
            }
            //Enemy bullet to player collision

            for (int i = 0;i < ebull.bulletNum1;i++)
            {
                ebull_to_player1[i] = Collision(ebull.x[i], ebull.y[i], myPlayer.pos.x, myPlayer.pos.y, myPlayer.avat.getWidth() / 2, ebull.width / 2);

                if (ebull_to_player1[i] == true)
                {
                    ebull.bulletNum1--;

                    HP_player.Hticks -= 1;
                }
            }

            if (lv.should_spawn() == true)
            {
                ;
                ebull.x[0] = Enemy.pos.x - 40;
                ebull.y[0] = Enemy.pos.y + 100;

                ebull.setup(phase_state, Enemy.pos);
            }
        }
        //Phase2:------------------------------------------------
       
        if (phase_state == "phase2")
        {
            ebull.setup(phase_state, Enemy.pos);

            if (lv.should_spawn() == true)
            {

                ebull.n += ebull.numBullets;
                ebull.createCircles(ebull.n, ebull.numBullets, ebull.x, ebull.y, ebull.R[ebull.bulletNum2], ebull.Input, ebull.x0, ebull.y0);

                for (int i = 0;i < ebull.bulletNum2;i++)
                {
                    ebull.R[ebull.bulletNum2] = 100;
                }
                ebull.bulletNum2++;

            }

            //Player Bullet to Enemy Collision
            for (int i = 0;i < bull.bulletNum;i++)
            {
                bull_to_enemy[i] = Collision(bull.x[i], bull.y[i], Enemy.pos2.x, Enemy.pos2.y, Enemy.r, bull.r);

                if (bull_to_enemy[i] == true)
                {
                    bull.bulletNum--;

                    HP_enemy.Hticks -= 2;;
                }
            }
            //Enemy Bullet to Player Collision
            for (int i = 0;i < ebull.n;i++)
            {
                ebull_to_player2[i] = Collision(ebull.x[i], ebull.y[i], myPlayer.pos2.x, myPlayer.pos2.y, myPlayer.r, ebull.r);

                if (ebull_to_player2[i] == true)
                {
                    deleteIndex(ebull.n, ebull.x, ebull.y, i);

                    HP_player.Hticks-=0.1;
                }
            }
            ebull.draw();
        }
        //-------------------------------------------------------------------------
        if (phase_state == "phase3")
        {
            //Player bullet to enemy Collision
            for (int i = 0;i < bull.bulletNum;i++)
            {
                bull_to_enemy[i] = Collision(bull.x[i], bull.y[i], Enemy.p2.x, Enemy.p2.y, Enemy.r, bull.r);

                if (bull_to_enemy[i] == true)
                {
                    bull.bulletNum--;

                    HP_enemy.Hticks -= 50;;
                }
            }
        }
        
    //Enemy to Player Collision
        
        enemy_to_player = Collision(myPlayer.pos2.x, myPlayer.pos2.y, Enemy.p2.x, Enemy.p2.y, myPlayer.r, Enemy.r);

        if (enemy_to_player == true)
        {
            Enemy.v *= Enemy.reverseX;
            HP_player.Hticks--;
        }
    }
    
    if(HP_enemy.Hticks == 0.0 )
    {
        game_state = "End1";
    }
    if(HP_player.Hticks <= 0.0)
    {
        game_state = "End2";
    }
    if(game_state == "End2")
    {
    gameEnd1.draw(250,200);
    }
    if(game_state == "End1")
    {
    gameEnd2.draw(250,200);
    }
}

//==================================================================================================
void ofApp::keyPressed(int key) {
   
    if (game_state == "game")
    {
        myPlayer.keyPressed(key);

        if (key == ' ') {
            float x, y;
            ofVec2f velocity = myPlayer.playerDirect * bull.speed;

            bull.bulletVelocity = velocity;

            x = myPlayer.pos.x;
            y = myPlayer.pos.y;

            //bull.x[0] = x + 125;
            //bull.y[0] = y + 35;

            bull.setup(myPlayer.pos, r, myPlayer.speed);

            myPlayer.avat.load("goku9.png");

            ki.loadSound("kiblast.mp3");
            ki.play();
        }
    }
   
}

//=====================================================================================================
void ofApp::keyReleased(int key) {
    if (key == ' ')
    {
        myPlayer.avat.load("2.png");
    }
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {

}
