#include "ofMain.h"
#include <iostream>
#include <fstream>
#include <string>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


using namespace std;

#ifndef Player_hpp
#define Player_hpp

#include <stdio.h>


#endif /* Player_h */

class Player
{
public:

    ofPoint pos;
    ofPoint pos2;
    ofImage avat;

    float speed;
    float r;

    ofVec2f playerDirect;

    Player();

    void print(string label);
    void setup();
    void draw();
    void keyPressed(int key);
};
