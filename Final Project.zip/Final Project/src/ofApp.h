#pragma once

#include "ofMain.h"
#include "Player.hpp"
#include "Bullets.hpp"
#include "Enemy.hpp"
#include "EnemBullets.hpp"
#include "lvctrl.hpp"
#include "HP.hpp"


class ofApp : public ofBaseApp {

public:

    Player myPlayer;
    Enemy Enemy;
    Bullets bull;
    EnemBullets ebull;
    lvctrl lv;
    HP HP_enemy;
    HP HP_player;

    ofSoundPlayer ki;

    ofImage gameEnd1;
    ofImage gameEnd2;

    string game_state;
    string phase_state;

    int score;
    float t = ofGetElapsedTimef();
    int r = 20;


    bool bull_to_enemy[N_MAX];
    bool ebull_to_player1[N_MAX];
    bool ebull_to_player2[N_MAX];
    bool enemy_to_player;

    bool Collision(float x1, float y1, float x2, float y2, float r1, float r2);
    void deleteIndex(int n, float x[], float y[], int index);

    void setup();
    void update();
    void draw();

    void keyPressed(int key);
    void keyReleased(int key);
    void mouseMoved(int x, int y);
    void mouseDragged(int x, int y, int button);
    void mousePressed(int x, int y, int button);
    void mouseReleased(int x, int y, int button);
    void mouseEntered(int x, int y);
    void mouseExited(int x, int y);
    void windowResized(int w, int h);
    void dragEvent(ofDragInfo dragInfo);
    void gotMessage(ofMessage msg);

};
