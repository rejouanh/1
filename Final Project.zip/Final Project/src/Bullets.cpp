#include "Bullets.hpp"

Bullets::Bullets()
{

}

void Bullets::print()
{
    printf("\n bulletx: %f ", x);
    printf("\n bulletx: %f ", y);

}


void Bullets::setup(ofPoint p, float r_in, float s)
{
    
    x[0] = p.x + 125;
    y[0] = p.y + 35;

    for (int i = bulletNum; i >= 0; i--)
    {

        x[i + 1] = x[i];
        y[i + 1] = y[i];
    }


    bulletNum++;
    r = r_in;

    speed = s;

}

void Bullets::draw(int red, int green, int blue)
{



    for (int i = 1; i < bulletNum; i++)
    {
        x[i] += bulletVelocity.x;
        y[i] += bulletVelocity.y;


        if (x[i] <= 0 || x[i]>=1024) {
           bulletNum--;
        }

        if (y[i] <= 0 || y[i]>=768) {
          bulletNum--;
        }

        ofSetColor(red, green, blue);
        ofFill();
        ofDrawCircle(x[i], y[i], r);

    }
}
