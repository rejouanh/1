#include "ofMain.h"
#include <iostream>
#include <fstream>
#include <string>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


using namespace std;

class Enemy
{

public:

    ofPoint pos;
    ofPoint pos2;
    float r;

    ofImage enem;


    bool movementY1;
    bool movementY2;
   

    //phase3
    string phases;
    
    ofVec2f p;
    ofVec2f p2;
    ofVec2f v;
    ofVec2f reverseX =  ofVec2f(-1,1);
    ofVec2f reverseY = ofVec2f(1, -1);

    Enemy();

    void setup(string phase);
    void draw();
};
