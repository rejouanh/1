#include "EnemBullets.hpp"


EnemBullets::EnemBullets()
{
    r = 20;
    n = 0;
    //bulletNum = 0;
    width = 150;
    height = 75;
    

}

EnemBullets::EnemBullets(float x0_in, float y0_in, float min_in, float max_in, float step_in, float r_in, float width_in, float height_in)
{
    r = r_in;
    width = width_in;
    height = height_in;
    min = min_in;
    max = max_in;
    x0 = x0_in;
    y0 = y0_in;

}

void EnemBullets::print(string label)
{
    //printf("\n-------%s----------\n", label);
    cout << "\n " << label;
    cout << "\n----------------\n";
    cout << "\n";

    printf("x: ");
    for (int i = 0;i < n;i++)
    {
        printf("%0.1f ", x[i]);
    }
    printf("\n\nc: ");
    for (int i = 0;i < n;i++)
    {
        printf("%0.1f ", y[i]);
    }
    printf("\n\nN:%d", n);
    printf("\n\nR: ");
    for (int i = 0;i < bulletNum1;i++)
    {
        printf("%0.1f ", R[i]);
    }
    printf("\n\n");
}

int EnemBullets::getUniformSamples(float Samp[], float min, float max, float step)
{
    int n2;

    n2 = (max - min) / step + 1;

    for (int i = 0;i < n2;i++)
    {
        Samp[i] = min + step * i;
    }

    return(n2);
}

void EnemBullets::createCircles(int n,int numBullets, float x[], float y[], float R, float theta[], float x0, float y0)
{
    for (int i = 0;i < numBullets;i++)
    {
        x[i+n] = x0 + R * cos(theta[i]);
        y[i+n] = y0 - R * sin(theta[i]);

    }

}

void EnemBullets::setup(string label,ofPoint p)
{
    phases = label;
        
    if (phases == "phase1")
    {
        for (int i = 0;i < bulletNum1;i++)
        {
            x[bulletNum1] = p.x;
            y[bulletNum1] = p.y;
        }

        for (int i = bulletNum1; i >= 0; i--)
        {
            x[i + 1] = x[i];
            y[i + 1] = y[i];
        }

        bulletNum1++;
    }

    if (phases == "phase2")
    {
        x0 = p.x +100;
        y0 = p.y + 100;
        step = PI / 8;
        min = 0;
        max = 2 * PI;

        numBullets = getUniformSamples(Input, min, max, step);

        for (int i = 0;i < bulletNum2;i++)
        {
            for (int j = 0;j < numBullets;j++)
            {
                x[j + 17 * i] = x0 + R[i] * cos(Input[j]);
                y[j + 17 * i] = y0 - R[i] * sin(Input[j]);
            }
        }
    }
}

void EnemBullets::update()
{

    if (phases == "phase2")
    {
        for (int i = 0;i < bulletNum2;i++)
        {
            R[i] += 3;
        }
    }
}
void EnemBullets::draw()
{
    if (phases == "phase1")
    {
        for (int i = 1; i < bulletNum1; i++)
        {
            x[i] -= 5;

            ofSetColor(255, 0, 0);
            ofFill();
            ofDrawRectangle(x[i], y[i], width, height);
        }
    }

    if (phases == "phase2")
    {
        for (int i = 0;i < n;i++)
        {
            
            ofSetColor(255, 0, 0);
            ofFill();

            ofDrawCircle(x[i], y[i], r);

            
        }
    }
    
}
