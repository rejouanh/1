#include "Player.hpp"

Player::Player()
{
    pos.x = 512;
    pos.y = 384;
    pos2.x = 575;
    pos2.y = 434;
    r = 70;
    speed = 25;
}

void Player::print(string label)
{
    cout << "\n object: " << label;
    cout << "\n x: " << pos.x;
    cout << "\n y: " << pos.y;
}

void Player::setup()
{
    avat.load("2.png");
}

void Player::draw()
{
    ofSetColor((255, 255, 255));
    avat.draw(pos.x, pos.y);

   
   // ofDrawCircle(pos2.x, pos2.y, r);

}

void Player::keyPressed(int key)
{
    if (key == OF_KEY_UP)
    {

        if (pos.y >= 10) pos.y -= speed;
        if (pos2.y >= 60) pos2.y -= speed;

        playerDirect = ofVec2f(0, -1);
    }
    if (key == OF_KEY_DOWN)
    {
        if (pos.y <= 655) pos.y += speed;
        if (pos2.y <= 700) pos2.y += speed;

        playerDirect = ofVec2f(0, 1);

    }
    if (key == OF_KEY_LEFT)
    {
        if (pos.x >= 0)pos.x -= speed;
        if (pos2.x >= r)pos2.x -= speed;

        playerDirect = ofVec2f(-1, 0);
    }
    if (key == OF_KEY_RIGHT)
    {
        if (pos.x <= 910)pos.x += speed;
        if (pos2.x <= 970)pos2.x += speed;

        playerDirect = ofVec2f(1, 0);
    }

}




