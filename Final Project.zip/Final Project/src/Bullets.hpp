#ifndef Bullets_h
#define Bullets_h

#include "ofMain.h"
#include <iostream>
#include <fstream>
#include <string>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


using namespace std;

#endif /* Bullets_h */

class Bullets
{
public:


    float x[1000];
    float y[1000];
    float r;

    int bulletNum;
    float speed;
    ofVec2f bulletVelocity;

    Bullets();

    void print();
    void setup(ofPoint p, float r_in, float s);
    void draw(int r, int g, int b);


};
