#include "Enemy.hpp"


Enemy::Enemy()
{
    pos.x = 850;
    pos.y = 250;
    pos2.x = 950;
    pos2.y = 350;
    r = 90;
    
    p.x = pos.x;
    p.y = pos.y;
    p2.x = pos2.x;
    p2.y = pos2.y;
    
    reverseX =  ofVec2f(-1,1);
    reverseY = ofVec2f(1, -1);
    v.x = 16;
    v.y = 8;
}

void Enemy::setup(string phase)
{
    phases = phase;
    enem.load("watta.png");
}

void Enemy::draw()
{
    
//Phase2:==========================================================
    if (phases == "phase2"||phases == "phase1")
    {
        if (pos.y == -20)
        {
            movementY1 = true;

        }
        if (pos.y == 590)
        {
            movementY1 = false;
        }

        if (movementY1 == true)
        {
            pos.y += 2;
        }
        else pos.y -= 2;

        //----------------------------
        if (pos2.y == 80)
        {
            movementY2 = true;

        }
        if (pos2.y == 690)
        {
            movementY2 = false;
        }

        if (movementY2 == true)
        {
            pos2.y += 2;
        }
        else pos2.y -= 2;
        
        
        ofFill();
        ofSetColor(255, 255, 255);
        enem.draw(pos.x,pos.y);

        //ofDrawCircle(pos2.x, pos2.y, r);
    }
//Phase3:========================================================
    if (phases == "phase3")
    {
        if (p.x < 0 || p.x > 900)
        {


            v *= reverseX;

        }
        if (p.y < 0 || p.y > 600)
        {
            v *= reverseY;

        }
        p += v;
        p2 += v;

        ofFill();
        ofSetColor(255, 255, 255);
        enem.draw(p);
    }


    //ofDrawCircle(p2.x, p2.y, r);
}
