#include "lvctrl.hpp"
lvctrl::lvctrl()
{
    
}

void lvctrl::setup(float s)
{
    start_time = s;
    
}
bool lvctrl::should_spawn()
{

    if (ofGetElapsedTimef() - start_time > interval_time) {
        start_time = ofGetElapsedTimef();
        return true;
    }
    return false;
}
