#include "ofMain.h"
#include <iostream>
#include <fstream>
#include <string>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


using namespace std;

class lvctrl
{

public:

    float start_time;
    float interval_time;
    
    lvctrl();

    void setup(float s);
    bool should_spawn();
};
